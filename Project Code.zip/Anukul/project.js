var page = document.getElementById("content-page")
function addGauge(page_content,low,high){
    page.innerHTML = page_content
    const gaugeElement=document.querySelector(".gauge");
    function setGaugeValue(gauge,value){
        console.log(gauge)
        if(value<0 || value>100){
            return;
        }
        console.log(low)
        console.log(high)
        gauge.querySelector(".gauge__fill").style.transform=`rotate(${value/200}turn)`;
        gauge.querySelector(".gauge__cover").textContent= `${Math.round(value*1)}%`;
    }
    setGaugeValue(gaugeElement,45);
}
document.getElementById("Temparature").onclick = ()=>{
    fetch('Temparature.html').then((response)=>{
        return response.text()
    }).then((data)=>{
        addGauge(data,0,100);
    })
}
document.getElementById("Debasish").onclick = ()=>{
    fetch('Debasish.html').then((response)=>{
        return response.text()
    }).then((data)=>{
        addGauge(data,0,50);
    })  
}
document.getElementById("Anukul").onclick = ()=>{
    fetch('Anukul.html').then((response)=>{
        return response.text()
    }).then((data)=>{
        // console.log(data)
        page.innerHTML = data;
    })  
}
document.getElementById("dashboard").onclick = ()=>{
    fetch('dashboard.html').then((response)=>{
        return response.text()
    }).then((data)=>{
        // console.log(data)
        page.innerHTML = data;
    })  
}
